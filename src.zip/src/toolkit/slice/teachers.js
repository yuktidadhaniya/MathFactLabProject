import { createSlice } from "@reduxjs/toolkit";
import axios from "config/axios";

const initialState = {
  fetchTeachersLoading: false,
  teachers: [],
  fetchTeachersError: "",
};

export const teachersSlice = createSlice({
  name: "teachers",
  initialState,
  reducers: {
    fetchTeachers: state => {
      state.fetchTeachersLoading = true;
    },
    fetchTeachersSuccess: (state, action) => {
      state.fetchTeachersLoading = false;
      state.teachers = action.payload.data;
    },
    fetchTeachersFailure: (state, action) => {
      state.fetchTeachersLoading = false;
      state.fetchTeachersError = action.payload.error;
    },
  },
});

export const getTeachers = () => async dispatch => {
  dispatch(fetchTeachers());
  axios
    .get(`/users/teachers?role_id=2`)
    .then(res => {
      console.log("res", res);
      dispatch(fetchTeachersSuccess(res.data));
    })
    .catch(error => {
      dispatch(fetchTeachersFailure({ error: error.response.data.message }));
    });
};

export const {
  fetchTeachers,
  fetchTeachersSuccess,
  fetchTeachersFailure,
} = teachersSlice.actions;

export default teachersSlice.reducer;
