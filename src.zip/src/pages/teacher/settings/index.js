import React from "react";

function Settings(props) {
  return <></>;
}

export default Settings;
