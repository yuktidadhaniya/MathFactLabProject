import React from "react";

// Animate star for animation
const AnimatedStar = props => {
  return (
    <div className="star-wrapper">
      <div className="star"></div>
      <div className="star"></div>
      <div className="star"></div>
      <div className="star"></div>
      <div className="star"></div>
      <div className="star"></div>
      <div className="star"></div>
      <div className="star"></div>
      <div className="star"></div>
      <div className="star"></div>
    </div>
  );
};

export default AnimatedStar;
