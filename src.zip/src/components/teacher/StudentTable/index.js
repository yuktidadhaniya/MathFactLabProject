import React, { useEffect, useState } from "react";
import { Table, Tag, Typography, Input, Form } from "antd";
import Section from "components/Section";
import Container from "components/Container";
import TeacherDialog from "components/TeacherDialog";
import ErrorBoundary from "components/ErrorBoundary";
import { useSelector } from "react-redux";
import PasswordSwitch from "components/PasswordSwitch";
import { useDispatch } from "react-redux";
import { getTeachers } from "toolkit/slice/teachers";
import "assets/sass/components/button-ant.scss";
import moment from "moment";
import { PlusOutlined } from "@ant-design/icons";
import { Button } from "antd";
import { Modal } from "antd";
import { EditOutlined } from "@ant-design/icons";

const { Title } = Typography;

// moment fromnow text changes
moment.updateLocale("en", {
  relativeTime: {
    s: "Seconds",
  },
});

export default function StudentTable(props) {
  const dispatch = useDispatch();

  // const { userDetails } = useSelector(({ auth }) => auth);
  const { teachers, fetchTeachersLoading } = useSelector(
    ({ teachers }) => teachers,
  );

  const [isShowAllPassword, setIsShowAllPassword] = useState(false);
  const [filteredInfo, setFilteredInfo] = useState({});
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [isShowClassCodeDialog, setIsShowClassCodeDialog] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  //Default set last name ascend order
  const [sortedInfo, setSortedInfo] = useState({
    column: {
      title: "Last Name",

      // dataIndex: "name1",
      // key: "name1",
      dataIndex: "last_name",
      key: "last_name",

      align: "center",
      showSorterTooltip: false,
    },

    // columnKey: "name1",
    // field: "name1",
    columnKey: "last_name",
    field: "last_name",
    order: "ascend",
  });

  useEffect(() => {
    !teachers.length && dispatch(getTeachers());
  }, []); // eslint-disable-line

  // const [sortedInfo, setSortedInfo] = useState({});
  const handleChangeTable = (pagination, filters, sorter) => {
    setFilteredInfo(filters);
    setSortedInfo(sorter);
  };

  // const [filterColumn, setFilterColumn] = useState([]);

  //reset selected row id after edit

  const handlePassword = () => {
    setIsShowAllPassword(!isShowAllPassword);
  };

  const handleAddclassName = () => {
    console.log("handleAddclassName: ", handleAddclassName);
    setIsModalOpen(true);
  };
  const handleCloseClassCodeDialog = () => {
    setIsModalOpen(false);
  };
  const handleEditClassCode = activeClassCode => {
    props.showEditClassCodeDialog(activeClassCode);
  };

  const onTitleChanged = e => setTitle(e.target.value);
  const columns = [
    {
      title: "First Name",
      dataIndex: "profile.first_name",
      key: "profile.first_name",
      align: "left",
      showSorterTooltip: false,
      sorter: (a, b) => a.last_name.localeCompare(b.last_name),
      sortOrder:
        sortedInfo.columnKey === "profile.first_name" && sortedInfo.order,
      render(text, record) {
        return {
          children: <div>{record.profile.first_name}</div>,
        };
      },
    },
    {
      title: "Username",
      dataIndex: "user_name",
      key: "user_name",
      align: "center",
      showSorterTooltip: false,
      sorter: (a, b) => a.user_name.localeCompare(b.user_name),
      sortOrder: sortedInfo.columnKey === "user_name" && sortedInfo.order,
    },

    {
      title: (
        <div onClick={() => handlePassword()} className="password-cell">
          Password
        </div>
      ),
      dataIndex: "password",
      align: "center",
      render(text, record) {
        return {
          children: (
            <div>
              <PasswordSwitch
                password={record.profile.password}
                isShowAllPassword={isShowAllPassword}
              />
            </div>
          ),
        };
      },
    },
    {
      title: "Edit",
      dataIndex: "edit",
      key: "edit",
      align: "center",
      render() {
        return {
          children: (
            <button
              type="button"
              className="btn-icon-trans edit"
              onClick={() => handleEditClassCode()}
            >
              {/* <i className="icon-edit" aria-hidden="true"></i> */}
              <EditOutlined />
            </button>
          ),
        };
      },
    },
    {
      title: "Class",
      dataIndex: "class_name",
      key: "class_name",
      align: "center",
      showSorterTooltip: false,
      filteredValue: filteredInfo.class_code || null,
      sorter: (a, b) =>
        a.profile.class_name.localeCompare(b.profile.class_name),
      sortOrder: sortedInfo.columnKey === "class_name" && sortedInfo.order,
      render(text, record) {
        return {
          children: <div>{record.profile.class_name}</div>,
        };
      },
    },

    {
      title: "Class code",
      dataIndex: "class_code",
      key: "class_code",
      align: "center",
      // filters: _.uniq(_.map(studentList, "profile.class_code")).map(code => {
      //   return { text: code, value: code };
      // }),
      showSorterTooltip: false,
      filteredValue: filteredInfo.class_code || null,
      // onFilter: (value, record) => record.profile.class_code.includes(value),
      sorter: (a, b) => (+a.class_code > +b.class_code ? -1 : 1),
      sortOrder: sortedInfo.columnKey === "class_code" && sortedInfo.order,
      render(text, record) {
        return {
          children: <div style={{ letterSpacing: 1 }}>{record.class_code}</div>,
        };
      },
      width: 120,
    },
    {
      title: "Last updated ",
      dataIndex: "updated_at",
      key: "updated_at",
      align: "center",
      sorter: (a, b) => new Date(a.updated_at) - new Date(b.updated_at),
      sortOrder: sortedInfo.columnKey === "updated_at" && sortedInfo.order,
      showSorterTooltip: false,

      render(text, record) {
        return {
          children: (
            <div>
              {record.profile.updated_at
                ? moment(record.profile.updated_at).fromNow()
                : ""}
            </div>
          ),
        };
      },
    },
  ];

  return (
    <Container fluid>
      <Section
        title={
          <div style={{ display: "grid", gridTemplateColumns: "auto auto" }}>
            <Title level={4} className={"tab-heading"}>
              All Teachers
              <span className="table-header-counter">
                <Tag> {teachers?.length}</Tag>
              </span>
            </Title>
          </div>
        }
        extra={
          <div className="google-classroom-section">
            <Button
              type="primary"
              size="small"
              onClick={handleAddclassName}
              className="joyride-2"
            >
              Add Class <PlusOutlined />
            </Button>
          </div>
        }
      >
        {isModalOpen ? (
          <ErrorBoundary>
            <TeacherDialog
              open={isModalOpen}
              closeClassCodePopup={handleCloseClassCodeDialog}
              isEditMode={false}
              activeClassCode={""}
              loading={false}
              title={isEditMode ? "Edit Class " : "New Class"}
            />
          </ErrorBoundary>
        ) : (
          ""
        )}

        {/* {isShowSelectClassDailog && (
            <ErrorBoundary>
              <SelectClassDailog
                open={isShowSelectClassDailog}
                // open={true}
                activeClassCode={activeClassCode}
                close={handleCloseClassSelectionDailog}
                loading={deleteClassCodeLoading}
              />
            </ErrorBoundary>
          )} */}
        <Table
          columns={columns}
          dataSource={teachers}
          onChange={handleChangeTable}
          loading={fetchTeachersLoading}
          scroll={{ y: "calc(100vh - 300px)", x: "1150" }}
          pagination={false}
          size="middle"
        />
      </Section>
    </Container>
  );
}
